import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

BOT_TOKEN = os.environ["BOT_TOKEN"]
OWNER_ID = int(os.environ["OWNER_ID"])
START_TEXT = "سلام جیگر ❤️\nپیامت رو بفرست تا به مالک ربات ارسال بشه."

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(START_TEXT)

async def incoming(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message:
        return
    user = update.effective_user
    chat = update.effective_chat
    if chat.type != "private":
        return
    # Header tells the owner exactly which user to reply to.
    name = (user.full_name or "بدون نام").replace("\n", " ")
    username = f"@{user.username}" if user.username else "بدون یوزرنیم"
    header = await context.bot.send_message(
        OWNER_ID,
        f"📩 پیام جدید\n👤 {name}\n🔹 {username}\n🆔 {user.id}\n\n↩️ برای پاسخ، روی همین پیام یا پیام محتوایی زیر Reply کن."
    )
    # Put the user ID in a tiny text message immediately before the content.
    # The owner can reply to this header to answer the user.
    await context.bot.copy_message(
        chat_id=OWNER_ID,
        from_chat_id=chat.id,
        message_id=update.message.message_id,
    )

async def owner_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.id != OWNER_ID or not update.message:
        return
    r = update.message.reply_to_message
    if not r:
        return
    # If replying to the header, extract the user id directly.
    target = None
    text = r.text or r.caption or ""
    marker = "🆔 "
    if marker in text:
        try:
            target = int(text.split(marker, 1)[1].split()[0])
        except Exception:
            pass
    # If replying to copied content, try to get original sender info when Telegram exposes it.
    if target is None and getattr(r, "forward_origin", None):
        origin = r.forward_origin
        if getattr(origin, "sender_user", None):
            target = origin.sender_user.id
    if target is None:
        await update.message.reply_text("برای پاسخ، روی پیام «📩 پیام جدید» Reply کن.")
        return
    try:
        await context.bot.copy_message(
            chat_id=target,
            from_chat_id=OWNER_ID,
            message_id=update.message.message_id,
        )
        await update.message.reply_text("✅ ارسال شد")
    except Exception as e:
        log.exception("reply failed")
        await update.message.reply_text("❌ ارسال نشد؛ ممکنه کاربر ربات رو بلاک کرده باشه.")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    log.exception("Unhandled error", exc_info=context.error)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(
        filters.Chat(OWNER_ID) & filters.REPLY & ~filters.COMMAND,
        owner_reply
    ))
    app.add_handler(MessageHandler(
        ~filters.Chat(OWNER_ID) & filters.ALL & ~filters.COMMAND,
        incoming
    ))
    app.add_error_handler(error_handler)
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
